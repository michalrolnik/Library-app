package com.example.clientside;

import com.example.clientside.model.Book;
import com.example.clientside.model.Request;
import com.google.gson.Gson;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import javafx.concurrent.Task;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.HashMap;
import java.util.Map;

public class MainController {


    @FXML
    private void openCustomerView(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("customer.fxml"));
        Parent root = loader.load();
        Stage stage = new Stage();
        stage.setScene(new Scene(root));
        stage.show();
    }

    @FXML
    private void openLibrarianView(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("librarian.fxml"));
        Parent root = loader.load();
        Stage stage = new Stage();
        stage.setScene(new Scene(root));
        stage.show();
    }

    public void openAddBookView(ActionEvent actionEvent) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("addBook.fxml"));
        Parent root = loader.load();
        Stage stage = new Stage();
        stage.setScene(new Scene(root));
        stage.show();
    }

    public void openSearchBookView(ActionEvent actionEvent) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("searchBook.fxml"));
        Parent root = loader.load();
        Stage stage = new Stage();
        stage.setScene(new Scene(root));
        stage.show();
    }

    public void openDeleteView(ActionEvent actionEvent) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("deleteBook.fxml"));
        Parent root = loader.load();
        Stage stage = new Stage();
        stage.setScene(new Scene(root));
        stage.show();
    }


    @FXML
    private TextField bookNameField;

    @FXML
    private TextField authorNameField;

    @FXML
    private TextField summaryField;

    @FXML
    private TextField bookSummaryField;

    @FXML
    private TextField yearField;

    @FXML
    private TextField bookNumberField;

    @FXML
    private Label searchResultLabel;

    @FXML
    private Label addResultLabel;

    @FXML
    private Label DelResultLabel;
    @FXML
    public void addBook(ActionEvent actionEvent) {
        String bookName = bookNameField.getText().trim();
        String authorName = authorNameField.getText().trim();
        String summary = summaryField.getText().trim();
        String yearText = yearField.getText().trim(); // Get text from yearField
        String bookNumberText = bookNumberField.getText().trim(); // Get text from bookNumberField

        // Check if yearText or bookNumberText is empty
        if (yearText.isEmpty() || bookNumberText.isEmpty()) {
            // Handle empty text fields

            System.out.println("Year or book number cannot be empty");
            addResultLabel.setText("Year or book number cannot be empty");
            return;
        }

        // Convert yearText and bookNumberText to integers
        int year;
        long bookNumber;
        try {
            year = Integer.parseInt(yearText);
            bookNumber = Long.parseLong(bookNumberText);
        } catch (NumberFormatException e) {
            // Handle invalid input
            System.out.println("Invalid year or book number format");
            addResultLabel.setText("Invalid year or book number format");


            return;
        }

        Book book = new Book(bookNumber, bookName, authorName, summary, year);
        addBookToServer(book);

        clearFields();
    }


    private void clearFields() {
        bookNameField.clear();
        authorNameField.clear();
        summaryField.clear();
        yearField.clear();
        bookNumberField.clear();
    }

    public void addBookToServer(Book book) {

            Task<Void> task = new Task<Void>() {
                @Override
                protected Void call() throws Exception {
                    try {
                        Gson gson = new Gson();
                        Map<String, Object> body = new HashMap<>();
                        body.put("book", book);
                        Request request = new Request("addBook", body);
                        String jsonRequest = gson.toJson(request);

                        String serverResponse = sendRequestToServer(request); // Use the existing method
                        javafx.application.Platform.runLater(() -> {
                            addResultLabel.setText(serverResponse);// Display the server response
                            System.out.println("serverResponse" +serverResponse);
                        });
                    }
                    catch (Exception e) {
                        javafx.application.Platform.runLater(() -> {
                            System.out.println("EROR="+ e.getMessage());

                            addResultLabel.setText("Error: " + e.getMessage()); // Display any errors
                        });
                    }
                    return null;
                }
            };
            new Thread(task).start();
        }




    @FXML
    public void deleteBook(ActionEvent actionEvent) {
        String bookNumberText = bookNumberField.getText().trim(); // Get text from bookNumberField

        // Check if bookNumberText is empty
        if (bookNumberText.isEmpty()) {
            // Handle empty text field
            System.out.println("Book number cannot be empty");
            DelResultLabel.setText("Book number cannot be empty!");
            return;
        }

        // Convert bookNumberText to a long
        long bookNumber;
        try {
            bookNumber = Long.parseLong(bookNumberText);
        } catch (NumberFormatException e) {
            // Handle invalid input
            System.out.println("Invalid book number format!");
            DelResultLabel.setText("Invalid book number format!");


            return;
        }

        // Create a map to store the book number
        Map<String, Object> body = new HashMap<>();
        body.put("bookNumber", bookNumber);

        // Create a request with the action "deleteBook" and the book number in the body
        Request request = new Request("deleteBookByNumber", body);

        // Send the request to the server
        Client.saveToServer(request);
        DelResultLabel.setText("deleted sucssefully");

        bookNumberField.clear();
    }



    @FXML
    public void searchBookByID(ActionEvent actionEvent) {

        String bookNumberText = bookNumberField.getText();

        // קביעת קריטריוני החיפוש במפתח-ערך
        Map<String, Object> searchCriteria = new HashMap<>();

        if (!bookNumberText.isEmpty()) {
            try {
                long bookNumber = Long.parseLong(bookNumberText);
                searchCriteria.put("bookNumber", bookNumber);
            } catch (NumberFormatException e) {
                searchResultLabel.setText("Invalid book number format.");
                return;
            }
        }

        // , כרגע זה מפה עם ערך אחד .שליחת בקשת חיפוש לשרת
        Request searchRequest = new Request("searchBookById", searchCriteria);
        Task<Void> task = new Task<Void>() {
            @Override
            protected Void call() throws Exception {
                try {
                    // Example of how you might structure the network call
                    String result = sendRequestToServer(searchRequest);
                    // Use Platform.runLater if you need to update the UI based on the result
                    javafx.application.Platform.runLater(() -> {
                        searchResultLabel.setText(result);
                    });
                } catch (Exception e) {
                    javafx.application.Platform.runLater(() -> {
                        searchResultLabel.setText("Error: " + e.getMessage());
                    });
                }
                return null;
            }
        };
        // Execute the task on a background thread
        new Thread(task).start();
    }

    public void searchBookBySummary(ActionEvent actionEvent) {String bookSummaryText = bookSummaryField.getText();

        // קביעת קריטריוני החיפוש במפתח-ערך
        Map<String, Object> searchCriteria = new HashMap<>();

        if (!bookSummaryText.isEmpty()) {
            System.out.println(bookSummaryText);
            searchCriteria.put("bookSummary", bookSummaryText);
            System.out.println(searchCriteria);
        }

        // , כרגע זה מפה עם ערך אחד .שליחת בקשת חיפוש לשרת
        Request searchRequest = new Request("searchBookBySummary", searchCriteria);
        Task<Void> task = new Task<Void>() {
            @Override
            protected Void call() throws Exception {
                try {
                    // Example of how you might structure the network call
                    String result = sendRequestToServer(searchRequest);
                    System.out.println("searchRequesr: :"+searchRequest);
                    // Use Platform.runLater if you need to update the UI based on the result
                    javafx.application.Platform.runLater(() -> {
                        searchResultLabel.setText(result);
                        System.out.println("result:"+result);
                    });
                } catch (Exception e) {
                    javafx.application.Platform.runLater(() -> {
                        System.out.println("E="+e.getMessage());
                        searchResultLabel.setText("Error: " + e.getMessage());
                    });
                }
                return null;
            }
        };
        // Execute the task on a background thread
        new Thread(task).start();
    }

    private String sendRequestToServer(Request request) {
        String serverResponse = "";
        try (Socket socket = new Socket("localhost", 12346);
             PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
             BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()))) {
            Gson gson = new Gson();
            String jsonRequest = gson.toJson(request);

            out.println(jsonRequest);

            // Assume the server sends a specific termination message to indicate the end of the response,
            // such as "END_OF_RESPONSE". If it's a single-line response, you can simply use 'readLine'.
            String line;
            while ((line = in.readLine()) != null && !line.equals("END_OF_RESPONSE")) {
                serverResponse += line + System.lineSeparator(); // System.lineSeparator() is used to maintain system compatibility
            }
        } catch (IOException e) {
            e.printStackTrace();
            return "Error: " + e.getMessage();
        }
        return serverResponse.trim(); // Remove trailing new line if needed
    }


}




