package com.example.clientside.model;

import java.util.Objects;

public class Book implements java.io.Serializable {


	private long id;
	String title;
	String author;
	String summary;
	int year;

	public Book() {
	}

	public Book(long id, String title, String author, String summary, int year) {
		this.id = id;
		this.title = title;
		this.author = author;
		this.summary = summary;
		this.year = year;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public int getYear() {
		return year;
	}

	public void setYear(int year) {
		this.year = year;
	}

	public Long getId() {
		return id;
	}

	public String getSummary() {
		return summary;
	}

	public void setSummary(String summary) {
		this.summary = summary;
	}

	public void setId(long id) {
		this.id = id;
	}
	@Override
	public boolean equals(Object o) {
		if (this == o) return true;
		if (o == null || getClass() != o.getClass()) return false;
		Book book = (Book) o;
		return Objects.equals(title, book.title) && Objects.equals(author, book.author) && Objects.equals(year, book.year);
	}

	@Override
	public int hashCode() {
		return Objects.hash(title, author, year);
	}


}
