package com.example.clientside;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class BookSearchApp extends Application {

    private Label bookDetailsLabel;

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Book Search Results");

        // יצירת תווית להצגת פרטי הספר
        bookDetailsLabel = new Label();

        // יצירת אזור מערך על מנת להציג את תווית הספר
        VBox vbox = new VBox(bookDetailsLabel);

        // יצירת הסצנה והצבת אזור המערך על הסצנה
        Scene scene = new Scene(vbox, 300, 200);
        primaryStage.setScene(scene);

        // הצגת החלון
        primaryStage.show();
    }

    // פונקציה לעדכון התווית עם פרטי הספר
    public void updateBookDetails(String bookDetails) {
        bookDetailsLabel.setText(bookDetails);
    }

    public static void main(String[] args) {
        launch(args);
    }
}
