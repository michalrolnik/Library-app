package com.example.clientside;


import com.example.clientside.model.Request;
import com.google.gson.Gson;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;

import static java.lang.System.out;

public class Client {

    static Gson gson = new Gson();

    public static void main(String[] args) {


    }

    public static String saveToServer(Request request) {
        PrintWriter writer = null;
        try {
            Socket myServer = new Socket("localhost", 12346);
            out.println("The server is up and running.");
            writer = new PrintWriter(myServer.getOutputStream(), true);
            String x = gson.toJson(request);

            writer.println(x);
            writer.flush();

                 BufferedReader in = new BufferedReader(new InputStreamReader(myServer.getInputStream(), "UTF-8")); {


                // Read response from server
                StringBuilder response = new StringBuilder();
                String line;
                while ((line = in.readLine()) != null) {
                    response.append(line);
                }

                return response.toString();
            }

        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }


    public static String receiveFromServer() {
        Socket serverSocket = null;
        try {
            serverSocket = new Socket("localhost", 12346); // יצירת חיבור חדש עם השרת
            BufferedReader reader = new BufferedReader(new InputStreamReader(serverSocket.getInputStream()));
            return reader.readLine(); // קריאת התוצאה מהשרת
        } catch (IOException e) {
            throw new RuntimeException(e);
        } finally {
            if (serverSocket != null) {
                try {
                    serverSocket.close(); // סגירת החיבור עם השרת בסיום הפעולה
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}
