module com.example.clientside {
    requires javafx.controls;
    requires javafx.fxml;
    requires com.google.gson;

    opens com.example.clientside to javafx.fxml;
    opens com.example.clientside.model to com.google.gson;
    exports com.example.clientside;
    exports com.example.clientside.model;

}
