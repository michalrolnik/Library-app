package dm;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class User implements Serializable{

	private Long id;
	private String name;
	private List<Long> bookIds = new ArrayList<>();
	
	public User() {}
	
	public User(Long id, String name, List<Long> bookIds) {
		super();
		this.id = id;
		this.name = name;
		this.bookIds = bookIds;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public List<Long> getBookIds() {
		return bookIds;
	}

	public void setBookIds(List<Long> bookIds) {
		this.bookIds = bookIds;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}


}
