package dm;

import java.util.Objects;

public class Book implements java.io.Serializable {
	
	private static final long serialVersionUID = 1L;
	private long id;
	private String title;
	private String author;
	private String summary;
	private int year;

	public Book() {
	}

	public Book(long id, String title, String author, String summary, int year) {
		this.id = id;
		this.title = title;
		this.author = author;
		this.summary = summary;
		this.year = year;
	}

	public String toDetailedString() {
		return "ID: " + id + ", Title: " + title + ", Author: " + author + ", Summary: " + summary + ", Year: " + year;
	}
	@Override
	public String toString(){

		return  Long.toString(id);

	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public String getSummary() {
		return summary;
	}

	public void setSummary(String summary) {
		this.summary = summary;
	}

	public int getYear() {
		return year;
	}

	public void setYear(int year) {
		this.year = year;
	}

	@Override
	public boolean equals(Object o) {
		if (this == o) return true;
		if (o == null || getClass() != o.getClass()) return false;
		Book book = (Book) o;
		return id == book.id && year == book.year && Objects.equals(title, book.title) && Objects.equals(author, book.author) && Objects.equals(summary, book.summary);
	}

	@Override
	public int hashCode() {
		return Objects.hash(title, author, year);
	}


}
