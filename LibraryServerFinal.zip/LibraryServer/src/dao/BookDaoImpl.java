package dao;

import com.google.gson.Gson;
import dm.Book;
import java.io.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class BookDaoImpl {
    private static final String FILE_PATH = "books.json";
    private static final Gson gson = new Gson();

    public BookDaoImpl() {
        if (emptyData()) {
            saveBooks(new HashMap<>());
        }
    }

    public void deleteBookById(Book entity) {
        Map<Long, Book> books = loadBooks();
        books.remove(entity.getId());
        saveBooks(books);
    }


    public void save(Book book) {
        Map<Long, Book> books = loadBooks();
        books.put(book.getId(), book);
        saveBooks(books);
    }

    public List<Book> findAll() {
        Map<Long, Book> books = loadBooks();
        return new ArrayList<>(books.values());
    }

    private boolean emptyData() {
        File file = new File(FILE_PATH);
        return !file.exists() || file.length() == 0;
    }

    public Map<Long, Book> loadBooks() {
        File file = new File(FILE_PATH);
        Map<Long, Book> books = new HashMap<>();
        try (Reader reader = new FileReader(file)) {
            //books = gson.fromJson(reader, new TypeToken<Map<Long, Book>>() {}.getType());
            Map<String, Object> rawMap = gson.fromJson(reader, Map.class);
            for (Map.Entry<String, Object> entry : rawMap.entrySet()) {
                Long key =Long.parseLong(entry.getKey());
                Book value = gson.fromJson(gson.toJson(entry.getValue()), Book.class);
                System.out.println(value.getTitle());
                books.put(key, value);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        return books;
    }

    private void saveBooks(Map<Long, Book> books) {
        try (Writer writer = new FileWriter(FILE_PATH)) {
            gson.toJson(books, writer);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


}
