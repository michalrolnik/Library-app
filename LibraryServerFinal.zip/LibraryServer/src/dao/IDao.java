package dao;

import dm.Book;

import java.io.IOException;
import java.util.List;

public interface IDao<ID extends java.io.Serializable,T> {
	void delete(T entity) throws IOException;
	T find(ID id) throws IllegalArgumentException, IOException;

	List<Book> findAll();

	boolean save(T entity) throws IllegalArgumentException;
}
