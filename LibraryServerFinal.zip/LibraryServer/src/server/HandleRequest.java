package server;

import com.google.gson.Gson;
import controller.BookController;
import dao.BookDaoImpl;
import dm.Book;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class HandleRequest implements Runnable {
    private final Socket clientSocket;
    private final Gson gson = new Gson();

    public HandleRequest(Socket socket) {
        this.clientSocket = socket;
    }

    @Override
    public void run() {
        try (
                BufferedReader reader = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
                PrintWriter writer = new PrintWriter(clientSocket.getOutputStream(), true)
        ) {
            String line = reader.readLine();
            System.out.println("Received from client: " + line);
            Request request = gson.fromJson(line, Request.class);
            String action = request.getAction();

            BookController bookController = new BookController(new BookDaoImpl());

            switch (action) {
                case "addBook":
                    Map<String, Object> body = request.getBody();
                    String bodyStr = gson.toJson(body.get("book"));
                    Book book = gson.fromJson(bodyStr, Book.class);
                    if(bookController.addNewBook(book)){
                        bookController.addNewBook(book);
                        sendResponse(writer, "Book added successfully.");}
                    else
                        sendResponse(writer, "Book is not added successfully.");

                    break;
                case "getAllBooks":
                    List<Book> allBooks = bookController.getAllBooks();
                    sendResponse(writer, gson.toJson(allBooks));
                    break;
                case "searchBookBySummary":
                    String summaryKeywords = request.getBody().get("bookSummary").toString();
                    List<Book> foundBooks = bookController.searchBookBySummary(summaryKeywords);

                    String response;
                    if (foundBooks.isEmpty()) {
                        response = "No books found with the given summary.";
                    } else {
                        response = formatBookList(foundBooks);
                    }

                    sendResponse(writer, response);
                    break;

                case "deleteBookByNumber":
                    Number number = (Number) request.getBody().get("bookNumber");
                    Long idToDelete = number.longValue();
                    boolean isDeleted = bookController.deleteBookById(idToDelete);
                    if (isDeleted) {
                        sendResponse(writer, "Book deleted successfully.");
                    } else {
                        sendResponse(writer, "Book not found or could not be deleted.");
                    }
                    break;

                case "searchBookById":
                    Long bookNumber = null;
                    String bookNumberStr="";
                    System.out.println("case: searchBookBId");

                    if (request.getBody().containsKey("bookNumber") && request.getBody().get("bookNumber") != null) {

                        double doubleValue = Double.parseDouble(request.getBody().get("bookNumber").toString());
                        int intValue = (int) Math.round(doubleValue);
                        bookNumberStr=Integer.toString(intValue);

                        if (bookNumberStr.matches("\\d+")) { // Check if it contains only digits

                            bookNumber = Long.parseLong(bookNumberStr);
                        }
                    }

                    if (bookNumber != null) {
                        Book foundBook = bookController.searchBookById(bookNumber);






                        if (foundBook != null) {
                            response = formatBook(foundBook);
                            sendResponse(writer, response);
                        } else {
                            sendResponse(writer, "Book not found");
                        }
                    } else {
                        sendResponse(writer, "Invalid book number format");
                    }
                    break;
                default:
                    sendResponse(writer, "Invalid action");
            }

        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                clientSocket.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    private String formatBook(Book foundBook) {

        return "ID: " + foundBook.getId() + ", Title: " + foundBook.getTitle() + ", Author: " + foundBook.getAuthor() +
                ", Summary: " + foundBook.getSummary() + ", Year: " + foundBook.getYear();

    }

    private String formatBookList(List<Book> foundBooks) {


            return foundBooks.stream()
                    .map(book -> "ID: " + book.getId() + ", Title: " + book.getTitle() + ", Author: " + book.getAuthor() +
                            ", Summary: " + book.getSummary() + ", Year: " + book.getYear())
                    .collect(Collectors.joining("\n"));

    }

    private void sendResponse(PrintWriter writer, String response) {
        writer.println(response);
        writer.flush();
    }
}
