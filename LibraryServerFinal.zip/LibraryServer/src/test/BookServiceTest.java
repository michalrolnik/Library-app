package test;



import dao.BookDaoImpl;
import dm.Book;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import service.BookService;

import java.util.List;

import static org.junit.Assert.*;

    public class BookServiceTest {
        private BookService bookService;
        private BookDaoImpl bookDao;

        @Before
        public void setUp() throws Exception {
            // Initialize your DAO here, possibly with an in-memory database
            bookDao = new BookDaoImpl();
            bookService = new BookService(bookDao);

            // Assuming you have a method in your DAO to add books for testing
            bookDao.save(new Book(1L, "Test Book 1", "Author1", "Summary1", 2023));
            bookDao.save(new Book(2L, "Test Book 2", "Author2", "Summary2", 2024));
        }

        @Test
        public void testAddNewBook() {
            Book newBook = new Book(3L, "New Book", "New Author", "New Summary", 2025);
            bookService.addNewBook(newBook);
            assertNotNull(bookService.searchBookById(3L));
        }

        @Test
        public void testGetAllBooks() {
            List<Book> books = bookService.getAllBooks();
            assertTrue(books.size() >= 2); // Assuming we start with 2 books
        }

        @Test
        public void testDeleteBookById() {
            assertTrue(bookService.deleteBookById(1L));
        }

        @Test
        public void testSearchBookBySummary() {
            List<Book> books = bookService.searchBookBySummary("Summary1");
            assertFalse(books.isEmpty());
            assertEquals("Test Book 1", books.get(0).getTitle());
        }

        @After
        public void tearDown() throws Exception {
            // Clean up the database or reset the DAO
        }
    }


