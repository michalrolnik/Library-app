package controller;

import dao.BookDaoImpl;
import dm.Book;
import service.BookService;

import java.util.List;

public class BookController {
    private final BookService bookService;

    public BookController(BookDaoImpl bookDao) {
        this.bookService = new BookService(bookDao);
    }
    public List<Book> getAllBooks() {
        return bookService.getAllBooks();
    }
    public boolean addNewBook(Book book) {
        Long id= book.getId();
        System.out.println("bookController addNewBook");

        if (bookService.searchBookById(id)==null) {
            bookService.addNewBook(book);
            return true;
        }
        else
            return false;
    }



    public boolean deleteBookById(Long number) {
        Book bookToDelete = bookService.searchBookById(number);
        if (bookToDelete != null) {
            return bookService.deleteBookById(number);
        }
        return false;
    }


    public Book searchBookById(Long id) {

        return bookService.searchBookById(id);
    }
    public List<Book> searchBookBySummary(String summary) {
        System.out.println("book contoler got the summary: "+summary);
       return bookService.searchBookBySummary(summary);
    }
    /*

    public List<Book> searchBookByName(String name) {
        return bookService.searchBookByName(name);
    }
*/
}
