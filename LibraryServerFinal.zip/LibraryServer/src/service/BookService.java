package service;

import dao.BookDaoImpl;
import dm.Book;
import main.IAlgoTextSearch;
import main.KmpSearch;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import main.IAlgoTextSearch;
import main.KmpSearch;

public class BookService {
	private final BookDaoImpl bookDao;
	IAlgoTextSearch stringSearchAlgo = new KmpSearch();

	public BookService(BookDaoImpl bookDao) {
		this.bookDao = bookDao;
	}

	public void addNewBook(Book book) {
		bookDao.save(book);
	}

	public List<Book> getAllBooks() {
		return bookDao.findAll();
	}

	public boolean deleteBookById(Long id) {
		// נשתמש ב-DAO כדי למצוא את הספר לפי ה- ID שלו
		Book bookToDelete = searchBookById(id);

		// בדיקה אם הספר קיים במאגר הנתונים
		if (bookToDelete != null) {
			// אם הספר נמצא, נמחק אותו מהמאגר הנתונים
			bookDao.deleteBookById(bookToDelete);
			return true; // מחיקה הצליחה
		} else {
			return false; // הספר לא נמצא במאגר הנתונים
		}
	}
	public Book searchBookById(Long id) {

		Map<Long, Book> books = bookDao.loadBooks();
		String bookIdAsString ;

		for (Book book : books.values()) {
			bookIdAsString = book.toString();
			System.out.println("id book" + book.toString());
			if (stringSearchAlgo.search(bookIdAsString, Long.toString(id)) == 0)
				if( bookIdAsString.length() == Long.toString(id).length()) {
				System.out.println(stringSearchAlgo.search(book.toString(), Long.toString(id)));
				return book;
			}
		}

		return null; // If no book matches the name
	}


	public List<Book> searchBookBySummary(String summaryKeywords) {
		System.out.println("book Service got the summary: "+summaryKeywords);
		Map<Long, Book> books= bookDao.loadBooks();
		List<Book> result = new ArrayList<>();
		String keywordsLower = summaryKeywords.toLowerCase();
		System.out.println("summary in lower case: "+keywordsLower);
		for (Book book : books.values()) {
			// Convert both strings to lower case to ensure case-insensitive search
			String bookSummaryLower = book.getSummary().toLowerCase();


			// Use the stringSearchAlgo to search for the keywords in the summary
			if (stringSearchAlgo.search(keywordsLower, bookSummaryLower) != -1) {
				System.out.println("match books "+book);
				result.add(book);
			}
		}
		System.out.println("result "+result);
		return result;
	}
}






