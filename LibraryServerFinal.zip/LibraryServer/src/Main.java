import server.Server;

import java.io.FileNotFoundException;

public class Main {
    public static void main(String[] args) throws FileNotFoundException {


//        Server server = new Server();
        Server.startServer();
    }

}